/*
You are developing a form validation system. Write a pro2ram that takes user information(such as name,
email, a2e) and uses the typeof operator to check the data type of each input. Print appropriate messa2es
like "Name should be a strin2" "Email should be a strin2," or "02e should be a number." if any field is not
proper.
*/

let Username = "mohit"
let email = 'yadavmoh09@gmail.com'
let age = '21'

if(typeof(Username) != "string")
    console.log("Name Should Be A String")
if(typeof(email) != "string")
    console.log("Email Should Be A String")
if(typeof(age) != "number")
    console.log("Age Should Be A Number")
