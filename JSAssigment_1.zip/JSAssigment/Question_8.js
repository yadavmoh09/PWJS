/*You are creatin2 a countdown app. Implement a pro2ram that uses a while loop to count down from 10 to 1
and prints each number.*/

let countDownNumber = 10

while(countDownNumber>=0){
    console.log(countDownNumber--);
}