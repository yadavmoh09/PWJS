/*2. You are building a simple login system+ Implement the login feature that has two variables: username and
password+ You should -he-k if the username is "admin" and the password is "12345"+ If both -Conditions are
true, print "Login successful"  otherwise, print "Invalid -Credentials"*/

let userName = 'admin'
let password = '123456'

if(userName =="admin" && password == "12345"){
    console.log("Login successful");
}else{
    console.log("Invalid Credentials");    
}
