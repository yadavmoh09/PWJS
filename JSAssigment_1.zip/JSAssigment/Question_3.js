/*You are working on a -urren-y -onversion appli-ation+ Write a program that has a variable whi-h stores the
amount in Indian Rupees (INR) and prints the equivalent amount in US Dollars (USD)+ Use the -urrent
ex-hange rate of 1 USD = 82 INR*/

let AmountInRupee = 850
let USDExchangeRate = 82
let AmountInUSD = AmountInRupee / USDExchangeRate
console.log(AmountInUSD);