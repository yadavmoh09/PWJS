/*You are buildin2 a simple shoppin2 list app. You have the items name in an array. Write a pro2ram that uses
a for loop to print all the items in the shoppin2 list array*/


let shoppingList = ["Product_1","Product_2","Product_3","Product_4","Product_5"]

for(let i = 0;i<shoppingList.length;i++){
    console.log(shoppingList[i])
}